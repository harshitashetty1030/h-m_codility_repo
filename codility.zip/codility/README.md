# Review Statistics API

A Node.js TypeScript backend service that provides statistics based on user reviews using the DummyJSON API. Features comprehensive logging, modular architecture, and service factory pattern.

## 🚀 Features

- **Average Rating**: Get the total average rating based on comment likes
- **Latest Comments**: Retrieve the 10 most recent comments with their ratings
- **Add Comment**: Create new comments with optional ratings
- **Structured Logging**: Comprehensive logging system with configurable levels
- **Service Factory Pattern**: Modular and testable architecture
- **SSL/TLS Bypass**: Development-friendly HTTPS certificate handling
- **Direct TypeScript Execution**: No build step required for development

## 📋 API Endpoints

### 1. Get Average Rating
```
GET /api/avg-rating
```
Returns the average rating (normalized from likes) and total number of comments.

**Main Response:**
```json
{
  "averageRating": 4.2,
  "totalComments": 340,
  "averageLikes": 8.5
}
```

### 2. Get Latest Comments
```
GET /api/latest-comments?limit=10
```
Returns the most recent comments with their likes (treated as ratings).

**Parameters:**
- `limit` (optional): Number of comments to return (default: 10)

**Main Response:**
```json
{
  "comments": [
    {
      "id": 1,
      "body": "This is some awesome thinking!",
      "postId": 242,
      "likes": 3,
      "user": {
        "id": 105,
        "username": "emmac",
        "fullName": "Emma Wilson"
      }
    }
  ]
}
```

### 3. Add Comment
```
POST /api/add-comment
```
Creates a new comment with optional rating.

**Request Body:**
```json
{
  "body": "This is an excellent post!",
  "postId": 1,
  "userId": 5,
  "rating": 4.5
}
```

**Main Response:**
```json
{
  "id": 341,
  "body": "This is an excellent post!",
  "postId": 1,
  "likes": 4.5,
  "user": {
    "id": 5,
    "username": "emmaj",
    "fullName": "Emma Miller"
  },
  "message": "Comment added successfully"
}
```

## 🛠️ Installation & Setup

### Prerequisites
- Node.js (v16 or higher)
- npm or yarn

### Quick Start

1. **Clone and install dependencies:**
```bash
git clone <repository-url>
cd codility
npm install
```

2. **Run the application:**
```bash
npm start
```

The API will be available at `http://localhost:3000`

### Development Mode
```bash
npm run dev
```

## 📊 Logging System

The application features a comprehensive logging system with structured output:

### Log Levels
- `ERROR`: Critical errors and exceptions
- `WARN`: Warning messages
- `INFO`: General information (default)
- `DEBUG`: Detailed debugging information

### Configuration
Set the log level using environment variables:
```bash
# Only errors and warnings
LOG_LEVEL=WARN npm start

# All logs including debug
LOG_LEVEL=DEBUG npm start

# Default (INFO level)
npm start
```

### Log Format
```
[2025-11-09T10:43:23.313Z] [INFO]  Initializing DummyJSON service | {"baseUrl":"https://dummyjson.com"}
```

## 🧪 API Testing

### Using curl:

1. **Add a comment:**
```bash
curl --location 'http://localhost:3000/add-comment' \
--header 'Content-Type: application/json' \
--data '{
    "body": "This is some awesome!!!!!!!",
    "postId": 242,
    "userId":2
}'
```

2. **Get average rating:**
```bash
curl --location 'http://localhost:3000/avg-rating'
```

3. **Get latest comments:**
```bash
curl --location 'http://localhost:3000/latest-comments?limit=5'
```


## 🏗️ Project Architecture

### Directory Structure
```
src/
├── controllers/          # Request handlers and business logic
│   └── comments.controller.ts
├── services/            # External API integration and data access
│   ├── dummyjson.service.ts
│   └── serviceFactory.ts
├── middleware/          # Express middleware functions
│   ├── errorHandler.ts
│   └── validation.ts
├── utils/              # Utility functions and helpers
│   └── logger.ts
├── interfaces/         # TypeScript interfaces and contracts
│   └── index.ts
├── config/            # Configuration files
├── types.ts           # Type definitions
├── routes.ts          # API route definitions
└── index.ts          # Application entry point
```

 
## 🔧 Configuration

### Environment Variables
- `NODE_ENV`: Application environment (development/production)
- `PORT`: Server port (default: 3000)
- `LOG_LEVEL`: Logging level (ERROR/WARN/INFO/DEBUG)
- `NODE_TLS_REJECT_UNAUTHORIZED`: SSL certificate handling (set to '0' for development)


### Rating Normalization
```typescript
// Normalize likes to 1-5 rating scale
const normalizedRating = Math.min(5, (averageLikes / 3) + 1);
```

## 🛡️ Security & Error Handling

### Security Middleware
- **Helmet**: Security headers
- **Input Validation**: Request body validation

### Error Handling
- Global error handler with structured logging
- Proper HTTP status codes
- Detailed error messages for development
- Graceful external API failure handling

### Logging Examples
```typescript
// Service operations
logger.info('Fetching comments', { limit, skip });
logger.error('Error fetching comments', { error: errorMessage, limit, skip });

// Controller operations  
logger.info('Processing add comment request', { postId, userId, bodyLength: body?.length });
```


## 📚 Technology Stack

- **Runtime**: Node.js
- **Language**: TypeScript
- **Framework**: Express.js
- **HTTP Client**: Axios
- **Security**: Helmet, CORS
- **Development**: ts-node, ts-node-dev
- **Architecture**: MVC with Service Layer

## 🔍 Monitoring & Debugging

### Log Analysis
All operations are logged with structured data:
```json
{
  "timestamp": "2025-11-09T10:43:23.313Z",
  "level": "INFO",
  "service": "BackendService", 
  "message": "Successfully added comment",
  "metadata": {
    "commentId": 341,
    "postId": 1,
    "userId": 5
  }
}
```

### Request Tracking
Each request includes:
- Request parameters and body
- Response data and status
- Error context and stack traces
- Performance metadata


## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Implement changes with proper logging
4. Add tests if applicable
5. Submit a pull request