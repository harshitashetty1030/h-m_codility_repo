import { Comment, DummyJSONResponse, AddCommentRequest } from '../types';

/**
 * Interface for comments service operations
 * This allows us to swap different implementations 
 */
export interface ICommentsService {
  /**
   * Get all comments with pagination
   */
  getAllComments(limit?: number, skip?: number): Promise<DummyJSONResponse>;  
 

  /**
   * Add a new comment
   */
  addComment(commentData: AddCommentRequest): Promise<Comment>;

  
  /**
   * Expose other methods like Get a single comment by ID, Get comments by post ID, Update an existing comment etc
   */
  
}

/**
 * Configuration interface for services
 */
export interface IServiceConfig {
  baseUrl: string;
  timeout: number;
  apiKey?: string;
  environment?: 'development' | 'production' | 'test';
}