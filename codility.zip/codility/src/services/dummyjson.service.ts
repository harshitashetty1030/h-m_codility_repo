import axios, { AxiosInstance } from 'axios';
import { Comment, DummyJSONResponse, AddCommentRequest } from '../types';
import { ICommentsService, IServiceConfig } from '../interfaces';
import https from 'https';
import { logger } from '../utils/logger';

// Disable SSL certificate verification for external HTTPS requests
process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '0';

export class DummyJSONService implements ICommentsService {
  private apiClient: AxiosInstance;
  private baseUrl: string;

  constructor(config: IServiceConfig) {
    this.baseUrl = config.baseUrl;
    
    logger.info('Initializing DummyJSON service', { baseUrl: config.baseUrl });
    
    // Configure axios instance with provided config
    this.apiClient = axios.create({
        baseURL: this.baseUrl,
        timeout: config.timeout
    });
  }
  /**
   * Get all comments with pagination
   */
  async getAllComments(limit: number = 30, skip: number = 0): Promise<DummyJSONResponse> {
    try {
      logger.info('Fetching comments', { limit, skip });
      const response = await this.apiClient.get('/comments', {
        params: { limit, skip }
      });
      logger.info('Successfully fetched comments', { count: response.data.comments?.length });
      return response.data;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('Error fetching comments', { error: errorMessage, limit, skip });
      throw new Error('Failed to fetch comments from DummyJSON');
    }
  }

  /**
   * Get a single comment by ID
   */
  async getCommentById(id: number): Promise<Comment> {
    try {
      logger.info('Fetching comment by ID', { id });
      const response = await this.apiClient.get(`/comments/${id}`);
      logger.info('Successfully fetched comment', { id });
      return response.data;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error(`Error fetching comment ${id}`, { error: errorMessage, id });
      throw new Error(`Failed to fetch comment with ID ${id}`);
    }
  }

  /**
   * Get comments by post ID
   */
  async getCommentsByPostId(postId: number): Promise<DummyJSONResponse> {
    try {
      const response = await this.apiClient.get(`/comments/post/${postId}`);
      return response.data;
    } catch (error) {
      console.error(`Error fetching comments for post ${postId}:`, error);
      throw new Error(`Failed to fetch comments for post ${postId}`);
    }
  }

  /**
   * Add a new comment (simulated)
   */
  async addComment(commentData: AddCommentRequest): Promise<Comment> {
    try {
      const response = await this.apiClient.post('/comments/add', {
        body: commentData.body,
        postId: commentData.postId,
        userId: commentData.userId
      }, {
        headers: {
          'Content-Type': 'application/json'
        }
      });
      
      // If rating is provided, we can store it locally or add it to the response
      const comment = response.data;
      if (commentData.rating) {
        comment.likes = commentData.rating; // Use rating as likes for consistency
      }
      
      return comment;
    } catch (error) {
      console.error('Error adding comment:', error);
      throw new Error('Failed to add comment');
    }
  }

}