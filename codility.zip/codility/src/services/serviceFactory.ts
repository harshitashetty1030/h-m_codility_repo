import { ICommentsService } from '../interfaces';
import { DummyJSONService } from './dummyjson.service';
import { config } from '../config';

/**
 * Service Factory - Creates and configures service instances
 * This makes it easy to swap implementations and manage dependencies
 */
export class ServiceFactory {
  private static commentsServiceInstance: ICommentsService | null = null;

  /**
   * Create or get singleton instance of comments service
   */
  static getCommentsService(): ICommentsService {
    if (!this.commentsServiceInstance) {
      this.commentsServiceInstance = this.createCommentsService();
    }
    return this.commentsServiceInstance;
  }

  /**
   * Create a new comments service instance
   * You can easily switch implementations here
   */
  private static createCommentsService(): ICommentsService {
    const environment = process.env.NODE_ENV || 'development';
    
    switch (environment) {
       
      case 'production':    //add production case here if needed
      case 'development':
      default:
        // Return DummyJSON service for production/development
        return new DummyJSONService(config.dummyJson);
    }
  }


  /**
   * Set custom service instance (useful for dependency injection in tests)
   */
  static setCommentsService(service: ICommentsService): void {
    this.commentsServiceInstance = service;
  }
}