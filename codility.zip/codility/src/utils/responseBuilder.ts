export interface ApiResponse<T = any> {
  success: boolean;
  message: string;
  data?: T;
  error?: {
    code: string;
    details?: any;
  };
  timestamp: string;
}

export class ResponseBuilder {
  /**
   * Create a successful response
   */
  static success<T>(data: T, message: string = 'Operation completed successfully'): ApiResponse<T> {
    return {
      success: true,
      message,
      data,
      timestamp: new Date().toISOString()
    };
  }

  /**
   * Create an error response
   */
  static error(message: string, code: string = 'INTERNAL_ERROR', details?: any): ApiResponse {
    return {
      success: false,
      message,
      error: {
        code,
        details
      },
      timestamp: new Date().toISOString()
    };
  }

  /**
   * Create a validation error response
   */
  static validationError(message: string, details?: any): ApiResponse {
    return ResponseBuilder.error(message, 'VALIDATION_ERROR', details);
  }

  /**
   * Create a not found error response
   */
  static notFound(message: string = 'Resource not found'): ApiResponse {
    return ResponseBuilder.error(message, 'NOT_FOUND');
  }

  /**
   * Create a server error response
   */
  static serverError(message: string = 'Internal server error', details?: any): ApiResponse {
    return ResponseBuilder.error(message, 'SERVER_ERROR', details);
  }
}

// Response utility functions for common patterns
export const ApiResponses = {
  success: ResponseBuilder.success,
  error: ResponseBuilder.error,
  validationError: ResponseBuilder.validationError,
  notFound: ResponseBuilder.notFound,
  serverError: ResponseBuilder.serverError
};