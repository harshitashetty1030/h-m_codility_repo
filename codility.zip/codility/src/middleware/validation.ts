import { Request, Response, NextFunction } from 'express';
import { AddCommentRequest } from '../types';

/**
 * Validation middleware for add comment endpoint
 */
interface ValidationErrorResponse {
    error: string;
    message: string    
}

export const validateAddComment = (req: Request, res: Response<ValidationErrorResponse>, next: NextFunction): void => {
    const { body, postId, userId } = req.body as AddCommentRequest;

    // Check if body exists and is not empty
    if (!body || typeof body !== 'string' || body.trim().length === 0) {
        res.status(400).json({
            error: 'Validation Error',
            message: 'Comment body is required and must be a non-empty string'
        });
        return;
    }

    // Validate body length
    if (body.trim().length > 1000) {
        res.status(400).json({
            error: 'Validation Error',
            message: 'Comment body must not exceed 1000 characters'
        });
        return;
    }

    // Validate postId
    if (!postId || !Number.isInteger(postId) || postId <= 0) {
        res.status(400).json({
            error: 'Validation Error',
            message: 'postId must be a positive integer'
        });
        return;
    }

    // Validate userId
    if (!userId || !Number.isInteger(userId) || userId <= 0) {
        res.status(400).json({
            error: 'Validation Error',
            message: 'userId must be a positive integer',
            
        });
        return;
    }

    // Trim body and continue
    req.body.body = body.trim();
    next();
};

/**
 * Validation middleware for query parameters
 */
export const validateLimit = (req: Request, res: Response, next: NextFunction): void => {
  const limitStr = req.query.limit as string;
  
  if (limitStr) {
    const limit = parseInt(limitStr);
    
    if (isNaN(limit) || limit < 1 || limit > 100) {
      res.status(400).json({
        error: 'Validation Error',
        message: 'Limit parameter must be a number between 1 and 100',
      });
      return;
    }
  }
  
  next();
};
 