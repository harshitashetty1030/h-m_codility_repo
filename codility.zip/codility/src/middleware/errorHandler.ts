import { Request, Response } from 'express';
import { logger } from '../utils/logger';
import { ApiResponses } from '../utils/responseBuilder';

/**
 * Global error handling middleware
 * This middleware catches all errors and sends a standardized error response
 */
export const errorHandler = (err: Error, req: Request, res: Response): void => {
  logger.error('Unhandled error occurred', {
    message: err.message,
    url: req.url,
    method: req.method,
    userAgent: req.get('User-Agent'),
    timestamp: new Date().toISOString()
  });
  
  const errorResponse = ApiResponses.serverError(
    err.message || 'Something went wrong!',
    { url: req.url, method: req.method }
  );
  
  res.status(500).json(errorResponse);
};


/**
 * Different error handlers can be added here for specific error types if needed
 */
 

