import { Request, Response, NextFunction } from 'express';
import { ICommentsService } from '../interfaces';
import { 
  AverageRatingData,
  LatestCommentsData, 
  AddCommentRequest, 
  AddCommentData 
} from '../types';
import { logger } from '../utils/logger';
import { ApiResponses } from '../utils/responseBuilder';

export class CommentsController {
  private commentsService: ICommentsService;

  constructor(commentsService: ICommentsService) {
    this.commentsService = commentsService;
  }
 

  /**
   * Get average rating of all comments
   */
  public getAverageRating = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      logger.info('Processing average rating request');
      
      // Get all comments (limit=0 gets all items)
      const allCommentsResponse = await this.commentsService.getAllComments(0, 0);
      const comments = allCommentsResponse.comments;

      if (comments.length === 0) {
        logger.warn('No comments found for average rating calculation');
        const emptyData: AverageRatingData = {
          averageRating: 0,
          totalComments: 0,
          averageLikes: 0
        };
        res.json(ApiResponses.success(emptyData, 'No comments found'));
        return;
      }

      // Calculate average likes (treating likes as ratings)
      const totalLikes = comments.reduce((sum: number, comment: any) => sum + comment.likes, 0);
      const averageLikes = totalLikes / comments.length;

      //Logic for computing the rating was borrowed from internet, as there was no rating field in DummyJSON comments
      // Normalize to 1-5 scale (assuming max likes could be around 10-15)
      // You can adjust this normalization based on actual data patterns
      const normalizedRating = Math.min(5, (averageLikes / 3) + 1);

      const responseData: AverageRatingData = {
        averageRating: Math.round(normalizedRating * 100) / 100,  
        totalComments: comments.length,
        averageLikes: Math.round(averageLikes * 100) / 100
      };

      logger.info('Successfully calculated average rating', { 
        averageRating: responseData.averageRating, 
        totalComments: responseData.totalComments 
      });
      res.json(ApiResponses.success(responseData, 'Average rating calculated successfully'));
    } catch (error) {
      logger.error('Error calculating average rating', { error: error instanceof Error ? error.message : 'Unknown error' });
      next(error);
    }
  };

  /**
   * Get latest comments with pagination. There is no timestamp, so we return the first 'limit' comments.
   */
  public getLatestComments = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      logger.info('Processing latest comments request', { limit });
      
      // Get recent comments (DummyJSON returns them in order, so we'll get the first 'limit' items)
      const commentsResponse = await this.commentsService.getAllComments(limit, 0);
      
      const responseData: LatestCommentsData = {
        comments: commentsResponse.comments
      };

      logger.info('Successfully retrieved latest comments', { 
        limit, 
        actualCount: responseData.comments.length 
      });
      res.json(ApiResponses.success(responseData, 'Latest comments retrieved successfully'));
    } catch (error) {
      logger.error('Error retrieving latest comments', { 
        error: error instanceof Error ? error.message : 'Unknown error',
        limit: req.query.limit 
      });
      next(error);
    }
  };

  /**
   * Add a new comment with optional rating
   */
  public addComment = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      // Validation is now handled by middleware 
      const { body, postId, userId } = req.body as AddCommentRequest;
      
      logger.info('Processing add comment request', { postId, userId, bodyLength: body?.length });

      const commentData: AddCommentRequest = {
        body,
        postId,
        userId
      };

      const newComment = await this.commentsService.addComment(commentData);

      const responseData: AddCommentData = {
        id: newComment.id,
        body: newComment.body,
        postId: newComment.postId,
        likes: newComment.likes,
        user: newComment.user
      };

      logger.info('Successfully added comment', { 
        commentId: newComment.id, 
        postId, 
        userId 
      });
      res.status(201).json(ApiResponses.success(responseData, 'Comment added successfully'));
    } catch (error) {
      logger.error('Error adding comment', { 
        error: error instanceof Error ? error.message : 'Unknown error',
        requestBody: req.body 
      });
      next(error);
    }
  };

}