// Controllers Index
// This file exports all controllers for easier importing

export { CommentsController } from './comments.controller';

// Can add more controllers here as application grows
// export { UserController } from './user.controller';
// export { AuthController } from './auth.controller';
// export { AdminController } from './admin.controller';