import express from 'express';
import helmet from 'helmet';
import routes from './routes';
import { errorHandler } from './middleware/errorHandler';
import { logger } from './utils/logger';
 
// Set NODE_ENV for development
if (!process.env.NODE_ENV) {
  process.env.NODE_ENV = 'development';
}

const app = express();
const port = process.env.PORT || 3000;

// Middleware
app.use(helmet());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Routes
app.use('/', routes);

app.use(errorHandler);

// Start server
app.listen(port, () => {
  logger.info(`API server running on port ${port}`, { port, nodeEnv: process.env.NODE_ENV });
  logger.info('Available endpoints:', {
    endpoints: [
      `GET  http://localhost:${port}/avg-rating`,
      `GET  http://localhost:${port}/latest-comments`,
      `POST http://localhost:${port}/add-comment`
    ]
  });
});

export default app;