export interface Comment {
  id: number;
  body: string;
  postId: number;
  likes: number;
  user: {
    id: number;
    username: string;
    fullName: string;
  };
}

export interface DummyJSONResponse {
  comments: Comment[];
  total: number;
  skip: number;
  limit: number;
}

// Data interfaces (without response wrapper)
export interface AverageRatingData {
  averageRating: number;
  totalComments: number;
  averageLikes: number;
}

export interface LatestCommentsData {
  comments: Comment[];
}

export interface AddCommentRequest {
  body: string;
  postId: number;
  userId: number;
  rating?: number; // Optional rating field for our API
}

export interface AddCommentData {
  id: number;
  body: string;
  postId: number;
  likes: number;
  rating?: number;
  user: {
    id: number;
    username: string;
    fullName: string;
  };
}

// Legacy types for backward compatibility (deprecated)
export interface AverageRatingResponse {
  averageRating: number;
  totalComments: number;
  averageLikes: number;
}

export interface LatestCommentsResponse {
  comments: Comment[];
}

export interface AddCommentResponse {
  id: number;
  body: string;
  postId: number;
  likes: number;
  rating?: number;
  user: {
    id: number;
    username: string;
    fullName: string;
  };
  message: string;
}