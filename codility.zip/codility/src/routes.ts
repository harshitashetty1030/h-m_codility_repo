import { Router } from 'express';
import { CommentsController } from './controllers';
import { ServiceFactory } from './services';
import { validateAddComment, validateLimit } from './middleware/validation';

const router = Router();

// Initialize services and controllers using factory
const commentsService = ServiceFactory.getCommentsService();
const commentsController = new CommentsController(commentsService);


// Main endpoints as requested
router.get('/avg-rating', commentsController.getAverageRating);
router.get('/latest-comments', validateLimit, commentsController.getLatestComments);
router.post('/add-comment', validateAddComment, commentsController.addComment);

export default router;