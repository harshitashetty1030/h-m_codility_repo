import { IServiceConfig } from '../interfaces';

/**
 * Application configuration
 */
export const config = {
  // Server configuration
  server: {
    port: parseInt(process.env.PORT || '3000'),
    environment: (process.env.NODE_ENV || 'development') as 'development' | 'production' | 'test'
  },

  // DummyJSON service configuration
  dummyJson: {
    baseUrl: process.env.DUMMYJSON_URL || 'https://dummyjson.com',
    timeout: parseInt(process.env.API_TIMEOUT || '10000'),
    environment: (process.env.NODE_ENV || 'development') as 'development' | 'production' | 'test'
  } as IServiceConfig
};

/**
 * Get configuration for a specific service
 */
export const getServiceConfig = (serviceName: keyof typeof config): any => {
  return config[serviceName];
};